// Chat System Configuration
const chatContainer = document.querySelector('.chat-container');
const messagesContainer = document.querySelector('.messages-container');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const usernameModal = document.getElementById('usernameModal');
const usernameInput = document.getElementById('usernameInput');
const usernameSubmit = document.getElementById('usernameSubmit');

// Chat State
let username = localStorage.getItem('chatUsername') || '';
let messages = JSON.parse(localStorage.getItem('chatMessages')) || [];

// Initialize Chat
function initChat() {
    // Set up event listeners first
    setupEventListeners();
    
    // Then check if we need to show the username modal
    if (!username) {
        // Ensure modal is visible
        if (usernameModal) {
            usernameModal.classList.remove('hidden');
            usernameInput.focus();
        }
    } else {
        // Ensure modal is hidden and load messages
        if (usernameModal) {
            usernameModal.classList.add('hidden');
        }
        loadMessages();
    }
}

// Username Modal
function showUsernameModal() {
    if (usernameModal) {
        usernameModal.classList.remove('hidden');
        usernameInput.focus();
    }
}

function hideUsernameModal() {
    if (usernameModal) {
        usernameModal.classList.add('hidden');
        usernameInput.value = ''; // Clear the input
    }
}

function handleUsernameSubmit() {
    const newUsername = usernameInput.value.trim();
    if (newUsername) {
        username = newUsername;
        localStorage.setItem('chatUsername', username);
        hideUsernameModal();
        loadMessages();
        
        // Add welcome message
        addMessage(`Welcome ${username}! You can now start chatting with other users.`, false);
    } else {
        // Show error if username is empty
        if (usernameInput) {
            usernameInput.classList.add('error');
            setTimeout(() => {
                usernameInput.classList.remove('error');
            }, 1000);
        }
    }
}

// Message Handling
function addMessage(content, isUser = false) {
    const message = {
        id: Date.now(),
        content,
        username: isUser ? username : 'System',
        timestamp: new Date().toISOString(),
        isUser
    };

    messages.push(message);
    localStorage.setItem('chatMessages', JSON.stringify(messages));
    displayMessage(message);
}

function displayMessage(message) {
    const messageElement = document.createElement('div');
    messageElement.className = `message ${message.isUser ? 'user' : 'other'} fade-in`;
    
    const usernameElement = document.createElement('div');
    usernameElement.className = 'message-username';
    usernameElement.textContent = message.username;
    
    const contentElement = document.createElement('div');
    contentElement.className = 'message-content';
    contentElement.textContent = message.content;
    
    const timeElement = document.createElement('div');
    timeElement.className = 'message-time';
    timeElement.textContent = new Date(message.timestamp).toLocaleTimeString();
    
    messageElement.appendChild(usernameElement);
    messageElement.appendChild(contentElement);
    messageElement.appendChild(timeElement);
    
    messagesContainer.appendChild(messageElement);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function loadMessages() {
    if (messagesContainer) {
        messagesContainer.innerHTML = ''; // Clear existing messages
        messages.forEach(message => displayMessage(message));
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

function handleSendMessage() {
    const content = messageInput.value.trim();
    if (content) {
        addMessage(content, true);
        messageInput.value = '';
    }
}

// Event Listeners
function setupEventListeners() {
    // Username modal event listeners
    if (usernameSubmit) {
        usernameSubmit.addEventListener('click', handleUsernameSubmit);
    }
    
    if (usernameInput) {
        usernameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleUsernameSubmit();
            }
        });
    }

    // Chat message event listeners
    if (sendButton) {
        sendButton.addEventListener('click', handleSendMessage);
    }
    
    if (messageInput) {
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
            }
        });
    }
}

// Initialize chat when DOM is loaded
document.addEventListener('DOMContentLoaded', initChat); 