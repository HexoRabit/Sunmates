// API Configuration
const NEWS_API_KEY = '2f3454fa52ea8dab90e3ef4bdd9336c2'; // Using the same API key as weather
const NEWS_API_URL = 'https://api.openweathermap.org/data/2.5/weather';

// DOM Elements
const newsSearch = document.getElementById('newsSearch');
const newsGrid = document.querySelector('.grid');

// Categories for news
const newsCategories = [
    { name: 'Featured', icon: '⭐' },
    { name: 'Climate', icon: '🌍' },
    { name: 'Hurricane', icon: '🌪️' },
    { name: 'Snow', icon: '❄️' },
    { name: 'Drought', icon: '🌡️' },
    { name: 'Technology', icon: '🔬' }
];

// Sample news data (since we don't have a news API)
const sampleNews = [
    {
        category: 'Featured',
        title: 'Major Storm System Expected to Impact Multiple States',
        description: 'A powerful storm system is expected to bring heavy rainfall and strong winds across several states this weekend.',
        source: 'Weather News',
        time: '2 hours ago'
    },
    {
        category: 'Climate',
        title: 'New Climate Study Reveals Alarming Trends',
        description: 'Recent research shows significant changes in global weather patterns over the past decade.',
        source: 'Climate Research',
        time: '5 hours ago'
    },
    {
        category: 'Hurricane',
        title: 'Hurricane Season Predictions for 2024',
        description: 'Experts forecast an above-average hurricane season with increased storm intensity.',
        source: 'Hurricane Watch',
        time: '1 day ago'
    },
    {
        category: 'Snow',
        title: 'Record Snowfall Hits Mountain Regions',
        description: 'Several mountain areas report unprecedented snowfall levels this winter season.',
        source: 'Winter Weather',
        time: '2 days ago'
    },
    {
        category: 'Drought',
        title: 'Drought Conditions Worsen in Western States',
        description: 'Severe drought conditions continue to affect water resources and agriculture.',
        source: 'Drought Watch',
        time: '3 days ago'
    },
    {
        category: 'Technology',
        title: 'Tornado Warning System Upgrades',
        description: 'New technology improves tornado detection and warning times for better public safety.',
        source: 'Technology',
        time: '4 days ago'
    }
];

// Function to create news card
function createNewsCard(news) {
    const category = newsCategories.find(cat => cat.name === news.category);
    const card = document.createElement('div');
    card.className = 'card bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 p-6';
    
    card.innerHTML = `
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-2">
                <span class="text-2xl">${category.icon}</span>
                <span class="text-sm font-semibold text-primary-500">${news.category}</span>
            </div>
            <span class="text-sm text-gray-500">${news.time}</span>
        </div>
        <h2 class="text-xl font-bold mb-3 text-gray-900 dark:text-white hover:text-primary-500 transition-colors duration-300">
            ${news.title}
        </h2>
        <p class="text-gray-600 dark:text-gray-300 mb-4">
            ${news.description}
        </p>
        <div class="flex items-center justify-between text-sm text-gray-500">
            <span>${news.source}</span>
        </div>
    `;
    
    return card;
}

// Function to filter news
function filterNews(searchTerm) {
    const filteredNews = sampleNews.filter(news => 
        news.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        news.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        news.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    displayNews(filteredNews);
}

// Function to display news
function displayNews(newsArray) {
    if (!newsGrid) return;
    
    newsGrid.innerHTML = '';
    newsArray.forEach(news => {
        const card = createNewsCard(news);
        newsGrid.appendChild(card);
    });
}

// Event Listeners
if (newsSearch) {
    newsSearch.addEventListener('input', debounce((e) => {
        filterNews(e.target.value.trim());
    }, 300));
}

// Initialize news display
document.addEventListener('DOMContentLoaded', () => {
    displayNews(sampleNews);
});

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
} 