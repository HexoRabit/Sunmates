// API Configuration
const WEATHER_API_KEY = '2f3454fa52ea8dab90e3ef4bdd9336c2';
const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5/weather';

// DOM Elements
const citySearch = document.getElementById('citySearch');
const weatherCard = document.getElementById('weatherCard');
const loadingState = document.getElementById('loadingState');
const errorMessage = document.getElementById('errorMessage');

// Weather Icons Mapping
const weatherIcons = {
    '01d': 'https://openweathermap.org/img/wn/01d@2x.png',
    '01n': 'https://openweathermap.org/img/wn/01n@2x.png',
    '02d': 'https://openweathermap.org/img/wn/02d@2x.png',
    '02n': 'https://openweathermap.org/img/wn/02n@2x.png',
    '03d': 'https://openweathermap.org/img/wn/03d@2x.png',
    '03n': 'https://openweathermap.org/img/wn/03n@2x.png',
    '04d': 'https://openweathermap.org/img/wn/04d@2x.png',
    '04n': 'https://openweathermap.org/img/wn/04n@2x.png',
    '09d': 'https://openweathermap.org/img/wn/09d@2x.png',
    '09n': 'https://openweathermap.org/img/wn/09n@2x.png',
    '10d': 'https://openweathermap.org/img/wn/10d@2x.png',
    '10n': 'https://openweathermap.org/img/wn/10n@2x.png',
    '11d': 'https://openweathermap.org/img/wn/11d@2x.png',
    '11n': 'https://openweathermap.org/img/wn/11n@2x.png',
    '13d': 'https://openweathermap.org/img/wn/13d@2x.png',
    '13n': 'https://openweathermap.org/img/wn/13n@2x.png',
    '50d': 'https://openweathermap.org/img/wn/50d@2x.png',
    '50n': 'https://openweathermap.org/img/wn/50n@2x.png'
};

// Weather Fetching
async function fetchWeather(city) {
    if (!city) {
        showError('Please enter a city name', errorMessage);
        return;
    }

    showLoading(loadingState);
    hideError(errorMessage);

    try {
        // First, try to get coordinates for the city
        const geoUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(city)}&limit=1&appid=${WEATHER_API_KEY}`;
        console.log('Fetching coordinates from:', geoUrl); // Debug log
        
        const geoResponse = await fetch(geoUrl);
        if (!geoResponse.ok) {
            throw new Error('Failed to fetch city coordinates');
        }
        
        const geoData = await geoResponse.json();
        console.log('Geo data received:', geoData); // Debug log

        if (!Array.isArray(geoData) || geoData.length === 0) {
            throw new Error('City not found. Please check the spelling and try again.');
        }

        const cityData = geoData[0];
        if (!cityData || typeof cityData.lat !== 'number' || typeof cityData.lon !== 'number') {
            throw new Error('Invalid city data received');
        }

        // Then fetch weather data using coordinates
        const weatherUrl = `${WEATHER_API_URL}?lat=${cityData.lat}&lon=${cityData.lon}&appid=${WEATHER_API_KEY}&units=metric`;
        console.log('Fetching weather from:', weatherUrl); // Debug log
        
        const weatherResponse = await fetch(weatherUrl);
        if (!weatherResponse.ok) {
            throw new Error('Failed to fetch weather data');
        }
        
        const weatherData = await weatherResponse.json();
        console.log('Weather data received:', weatherData); // Debug log

        displayWeather(weatherData);
    } catch (error) {
        console.error('Weather fetch error:', error);
        showError(error.message || 'Failed to fetch weather data. Please try again.', errorMessage);
        weatherCard.classList.add('hidden');
    } finally {
        hideLoading(loadingState);
    }
}

function displayWeather(data) {
    try {
        const weatherIcon = document.getElementById('weatherIcon');
        const cityName = document.getElementById('cityName');
        const temperature = document.getElementById('temperature');
        const weatherDescription = document.getElementById('weatherDescription');
        const feelsLike = document.getElementById('feelsLike');
        const humidity = document.getElementById('humidity');
        const windSpeed = document.getElementById('windSpeed');

        if (!weatherIcon || !cityName || !temperature || !weatherDescription || 
            !feelsLike || !humidity || !windSpeed) {
            throw new Error('Required DOM elements not found');
        }

        // Set weather icon
        const iconCode = data.weather[0].icon;
        weatherIcon.src = weatherIcons[iconCode] || weatherIcons['01d'];
        weatherIcon.alt = data.weather[0].description;

        // Set weather information
        cityName.textContent = `${data.name}, ${data.sys.country}`;
        temperature.textContent = Math.round(data.main.temp);
        weatherDescription.textContent = data.weather[0].description.charAt(0).toUpperCase() + data.weather[0].description.slice(1);
        feelsLike.textContent = `${Math.round(data.main.feels_like)}°C`;
        humidity.textContent = `${data.main.humidity}%`;
        windSpeed.textContent = `${Math.round(data.wind.speed)} m/s`;

        // Show weather card with animation
        weatherCard.classList.remove('hidden');
        weatherCard.classList.add('fade-in');
    } catch (error) {
        console.error('Display error:', error);
        showError('Error displaying weather data. Please try again.', errorMessage);
        weatherCard.classList.add('hidden');
    }
}

// Event Listeners
if (citySearch) {
    // Search on Enter key
    citySearch.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const city = e.target.value.trim();
            if (city) fetchWeather(city);
        }
    });

    // Search on input change (optional)
    let debounceTimer;
    citySearch.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            const city = e.target.value.trim();
            if (city) fetchWeather(city);
        }, 500);
    });
}

// Utility Functions
function showLoading(element) {
    if (element) element.classList.add('active');
}

function hideLoading(element) {
    if (element) element.classList.remove('active');
}

function showError(message, element) {
    if (element) {
        element.textContent = message;
        element.classList.remove('hidden');
        element.classList.add('fade-in');
    }
}

function hideError(element) {
    if (element) {
        element.classList.add('hidden');
        element.classList.remove('fade-in');
    }
}

// Initialize weather for a default city
document.addEventListener('DOMContentLoaded', () => {
    fetchWeather('London'); // Default city
}); 